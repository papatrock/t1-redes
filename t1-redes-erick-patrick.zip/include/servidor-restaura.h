#include "soquete-lib.h"

void handle_restaura(unsigned char* buffer, int soquete, struct sockaddr_ll path_addr,unsigned char *sequencia);